#include "functions.h"

functions::functions()
{

}
